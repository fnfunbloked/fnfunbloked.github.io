<?php
$social = array();
$social['facebook_profile'] = '#';
$social['instagram'] = '#';
$social['twitter_profile'] = '#';
?>