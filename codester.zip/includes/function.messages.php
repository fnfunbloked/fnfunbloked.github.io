<?php
//Author :: Deluxe Script
//Name :: GAMEZ PHP Script
function success($text) {
	return '<div class="alert alert-success"><i class="fa fa-check"></i> '.$text.'</div>';
}

function error($text) {
	return '<div class="alert alert-danger"><i class="fa fa-times"></i> '.$text.'</div>';
}

function info($text) {
	return '<div class="alert alert-info"><i class="fa fa-info-circle"></i> '.$text.'</div>';
}
function warn($text) {
	return '<div class="alert alert-warning"><i class="fa fa-info-circle"></i> '.$text.'</div>';
}
?>