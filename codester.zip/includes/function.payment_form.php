<?php
//Author :: Deluxe Script
//Name :: GAMEZ PHP Script
?>