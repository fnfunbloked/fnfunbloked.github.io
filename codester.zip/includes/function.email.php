<?php
//Author :: Deluxe Script
//Name :: GAMEZ PHP Script
function EmailSys_Send_Email_Verification($email) {
	global $db, $settings, $smtpconf;
	$eQuery = $db->query("SELECT * FROM users WHERE email='$email'");
	if($eQuery->num_rows>0) {
		$row = $eQuery->fetch_assoc();
		$to = $row['email'];
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = $smtpconf["host"];
		$mail->Port = $smtpconf["port"];
		$mail->SMTPAuth = $smtpconf['SMTPAuth'];
		$mail->Username = $smtpconf["user"];
		$mail->Password = $smtpconf["pass"];
		$mail->setFrom($settings['infoemail'], $settings['name']);
		$mail->addAddress($to, $to);
		//Set the subject line
		$lang = array();
		$mail->Subject = 'Activate your '.$settings[name].' account';
		$tpl = new Template("templates/Email_Templates/Email_Verification.tpl",$lang);
		$tpl->set("url",$settings['url']);
		$tpl->set("name",$settings['name']);
		$tpl->set("email",$row['email']);
		$tpl->set("hash",$row['email_hash']);
		$email_template = $tpl->output();
		$mail->msgHTML($email_template);
		//Replace the plain text body with one created manually
		$mail->AltBody = '['.$settings[name].'] Account verification';
		//Attach an image file
		//send the message, check for errors
		$send = $mail->send();
		if($send) { 
			return true;
		} else {
			return false;
		}
	}
}

function EmailSys_Send_Password_Reset($email) {
	global $db, $settings, $smtpconf;
	$eQuery = $db->query("SELECT * FROM users WHERE email='$email'");
	if($eQuery->num_rows>0) {
		$row = $eQuery->fetch_assoc();
		$to = $row['email'];
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = $smtpconf["host"];
		$mail->Port = $smtpconf["port"];
		$mail->SMTPAuth = $smtpconf['SMTPAuth'];
		$mail->Username = $smtpconf["user"];
		$mail->Password = $smtpconf["pass"];
		$mail->setFrom($settings['infoemail'], $settings['name']);
		$mail->addAddress($to, $to);
		//Set the subject line
		$lang = array();
		$mail->Subject = 'Recover your '.$settings[name].' account password';
		$tpl = new Template("templates/Email_Templates/Password_Reset.tpl",$lang);
		$tpl->set("url",$settings['url']);
		$tpl->set("name",$settings['name']);
		$tpl->set("email",$row['email']);
		$tpl->set("hash",$row['password_recovery']);
		$email_template = $tpl->output();
		$mail->msgHTML($email_template);
		//Replace the plain text body with one created manually
		$mail->AltBody = 'Recover your '.$settings[name].' account password';
		//Attach an image file
		//send the message, check for errors
		$send = $mail->send();
		if($send) { 
			return true;
		} else {
			return false;
		}
	}
}

function EmailSys_Send_2FA_Code($email,$code) {
	global $db, $settings, $smtpconf;
	$eQuery = $db->query("SELECT * FROM users WHERE email='$email'");
	if($eQuery->num_rows>0) {
		$row = $eQuery->fetch_assoc();
		$to = $row['email'];
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = $smtpconf["host"];
		$mail->Port = $smtpconf["port"];
		$mail->SMTPAuth = $smtpconf['SMTPAuth'];
		$mail->Username = $smtpconf["user"];
		$mail->Password = $smtpconf["pass"];
		$mail->setFrom($settings['infoemail'], $settings['name']);
		$mail->addAddress($to, $to);
		//Set the subject line
		$lang = array();
		$mail->Subject = $settings[name].' 2FA';
		$tpl = new Template("templates/Email_Templates/2FA_Auth.tpl",$lang);
		$tpl->set("url",$settings['url']);
		$tpl->set("name",$settings['name']);
		$tpl->set("email",$row['email']);
		$tpl->set("code",$code);
		$email_template = $tpl->output();
		$mail->msgHTML($email_template);
		//Replace the plain text body with one created manually
		$mail->AltBody = $settings[name].' 2FA';
		//Attach an image file
		//send the message, check for errors
		$send = $mail->send();
		if($send) { 
			return true;
		} else {
			return false;
		}
	}
}
?>