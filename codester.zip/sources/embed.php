<?php
	if(isset($_POST["gameFrame"]) && $_POST["gameFrame"] == "true") {
        $play = $_POST["play"];
        $timer = $_POST["gftm"];
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') { 

            $slug = addslashes(protect(htmlspecialchars($_GET["play"])));
            $game_check = $db->query("SELECT * FROM games WHERE Slug='$slug'");
            if($game_check && $game_check->num_rows > 0) {
                if($play == "1") {
                    $db->query("UPDATE games SET Played=Played+1 WHERE Slug='$slug'");
                    exit("ok");
                } else if($timer == "1") {
                    $db->query("UPDATE games SET Playtime=Playtime+1 WHERE Slug='$slug'");
                    exit("ok");
                }
            } else {
                exit("error");
            }
        } else{ 
            exit("not ajax");
        }
    }
      
      if(isset($_GET["embed"]) && !empty($_GET["embed"])) {
      $Md = protect($_GET["embed"]);
      $game_check = $db->query("SELECT * FROM games WHERE Slug='$Md' and status='enable'");
      if($game_check && $game_check->num_rows > 0) {
        $game_data = $game_check->fetch_assoc();
?>



<script>
  var clickIframe = window.setInterval(checkFocus, 1000);
  var i = 0;

  function checkFocus() {
    if(document.activeElement == document.getElementById("gameFrame")) {
      if(i == "5") {
        $.ajax({
          type: "POST",
          url: window.location.href,
          data: "gameFrame=true&play=1",
          success: function() {}
        });
      }else if(i > 10) {
        $.ajax({
          type: "POST",
          url: window.location.href,
          data: "gameFrame=true&gftm=1",
          success: function() {}
        });
      }
      i++;
    }
  }
</script>



<body style="margin:0px;padding:0px;overflow:hidden">
  <iframe id="gameFrame" class="game-frame" src="<?=$game_data["Url"];?>" scrolling="none" style="overflow:hidden;height:100%;width:100%" frameborder="0" title="<?=$game_data["Title"];?>" allowfullscreen height="100%" width="100%"></iframe>
</body>


<?php
    
  } else {
    header("Location: /");
  }
  
}
?>