<?=advertisement(2);?>
<section class="detailHome padder1">
	<div class="container">
      	<div class="row">
			<div class="col-md-12 mt30">
				<h2 class="cfirst"><?=$settings['footer_section_h1']?></h2>
				<p class="cgray">
				    <?=$settings['footer_section_text']?>
                    <a href="/subject/trend">Discover all games!</a>
				</p>
			</div>
		</div>
      	<div class="row">
			<div class="col-md-6 mt30">
				<h2 class="cfirst"><?=$settings['footer_section_part_1_h1']?></h2>
				<p class="cgray">
				    <?=$settings['footer_section_part_1_text']?>
				</p>
              	<p></p>
			</div>
			<div class="col-md-3 mt30">
				<h2><?=$settings['footer_section_part_2_h1']?></h2>
				<p class="cgray">
				    <?=$settings['footer_section_part_2_text']?>
				</p>
			</div>
			<div class="col-md-3 mt30">
				<h2><?=$settings['footer_section_part_3_h1']?></h2>
				<p class="cgray">
				    <?=$settings['footer_section_part_3_text']?>
				</p>
			</div>
		</div>
	</div>
</section>
<section class="footer fs12 cgray">
	<div class="container" >
		<div class="row">
			<div class="col-md-6">
				All rights reserved by EilGames.com &copy; 2022
			</div>
			<div class="col-md-6" align="right">
				<div class="footLinks">
					<a href="/contact">Contact</a>
					<a href="/page/terms">Terms of conditons</a>
					<a href="/page/privacy">Privacy policy</a>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$('.homeSlider').slick({
	infinite: true,
	slidesToShow: 3,
	slidesToScroll: 3,
	responsive: [
	{
	  breakpoint: 992,
	  settings: {
	    slidesToShow: 2,
	    slidesToScroll: 2,
	  }
	},
	{
	  breakpoint: 400,
	  settings: {
	    slidesToShow: 1,
	    slidesToScroll: 1,
	  }
	}
	]
});
$(".rightBtn").click(function(){
	$(this).parent().children().children(".slick-next").trigger('click');
});
$(".leftBtn").click(function(){
	$(this).parent().children().children(".slick-prev").trigger('click');
});
$(".bar").click(function(){
	$(".navSlide").slideToggle();
});
$(".dropdownClick").click(function(){
	$(this).parent().children(".dropdownUl").slideToggle();
});
$('.popSlider').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 6,
  slidesToScroll: 6,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll:21
      }
    }
  ]
});
});
$(".copyEmbedBtn").click(function(){
    $(".embedTxt").select();
    document.execCommand('copy');
    $(".copyTxt").text("Copied!");
    setTimeout(function(){
	    $(".copyTxt").text("Copy Embed Code");
    }, 1000);
});
var elem = document.getElementById("gameFrame");
function openFullscreen() {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
  }
}
</script>
<img src="/assets/img/mainBack.jpg" alt="<?=$settings['name'];?>" class="mainBack">
<script src="/assets/js/slick.min.js"></script>
</body>
</html>