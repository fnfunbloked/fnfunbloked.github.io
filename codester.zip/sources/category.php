<?php
include("header.php"); 

if(isset($_GET["category"]) && !empty($_GET["category"])){
  $category = isset($_GET['category']) ? addslashes(protect($_GET['category'])) : "";
  $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
  if($category_check && $category_check->num_rows > 0) {
    $category_data = $category_check->fetch_assoc();
    $category_name = $category_data["name"];
?>


<section class="homeSec2 padder1">
	<div class="container">
        <?=advertisement(2);?>
		<div class="flex ai jcb heading1Flex">
			<h2 class="heading1"><img src="/assets/img/gameIcom.png" width="23px"> &nbsp; <span class="cfirst">#<?=$category_data["name"];?></span> Games</h2>
		</div>


		<div class="row">
							

          
          
          	<?php
            $page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
            $limit = 102;
            $startpoint = ($page * $limit) - $limit;
            if($page == 1) {
              $i = 1;
            } else {
              $i = $page * $limit;
            }
            $statement = "games  WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC";
            $query = $db->query("SELECT * FROM {$statement} LIMIT {$startpoint} , {$limit}");

            if($query->num_rows > 0) {
              while($data = $query->fetch_assoc()) {
                $active_thumbnail = $data["ActiveThumbnail"];
                $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                $img_folder = $site_url."/uploads/images/";

                if($active_thumbnail == 1) {
                  $thumbnail = $img_folder.$data["image_store_url"];
                }else {
                  $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                }
           	?>
          
			<div class="col-md-2 col-xs-6">
				<a href="/play/<?=$data["Slug"];?>" class="gameBox2 block td rel" alt="<?=$data["Title"];?>">
					<img src="<?=$thumbnail;?>" loading="lazy" class="gameBox2Img" alt="<?=$data["Title"];?>">
					<div class="gameBox2Inner">
						<p class="gameBox2Title abs cwhite"><?=$data["Title"]?></p>
					</div>
				</a>
			</div>

			<?php } } ?>	


		</div>
		
      
      	<div class="text-center">
              <!--Add Pagination -->
          
          		<?php
  
  				$ver = "/category/$_GET[category]";
                if(web_paginationme($statement,$ver,$limit,$page)) {
                  echo web_paginationme($statement,$ver,$limit,$page);
                }	
  					
  				?>
          
        </div>
      

	</div>
</section>

<?php } } ?>


<?php  include("footer.php"); ?>