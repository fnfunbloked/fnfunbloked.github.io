<?php
include("header.php"); 
?>
<section class="sliderHome cwhite">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="homeSlidInner">
					<h1 class="fw2 fs50">Have <span class="cfirst">Endless</span> Fun</h1> <br>
					<p class="fs15 cgray">
						Enjoy an exciting gaming experience without spending a penny, with access to over 20,000 games on our portal. Let the fun begin!
					</p>
					<br>
					<div class="flex">
						<a href="/subject/all" class="btn1 sliderBtn fw3 inline br8 td "><i class="fa fa-gamepad"></i> &nbsp; All Games</a>
						&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="/subject/trend" class="btn2 sliderBtn fw3 inline br8 td "><i class="fa fa-th-large"></i> &nbsp; Trending</a>
					</div>
				</div>
			</div> 
			<div class="col-md-8 rel sliderBack">
				<div class="homeSlider">
                  	<?php
                    $max_featured_games = 6;
                    $featured_games = $db->query("SELECT * FROM games WHERE Featured='yes' and status='enable' ORDER BY Played DESC LIMIT $max_featured_games");
                    if($featured_games->num_rows > 0) {
                        while($data = $featured_games->fetch_assoc()) {
                            $active_thumbnail = $data["ActiveThumbnail"];
                            $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                            $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                            $img_folder = $site_url."/uploads/images/";

                            if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                            }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                            }
                     ?>
					<div class="homeSlide">
						<a href="/play/<?=$data["Slug"];?>" class="homeSlideBox td" title="<?=$data["Title"];?>">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>">
							<div class="inner">
								<p><?=$data["Title"]?></p>
								<span>Featured Game</span>
							</div>
						</a>
					</div>
                  	<?php } } ?>
				</div>
				<img src="/assets/img/leftArrow.png" class="leftArrow leftBtn slideBtn" alt="<?=$settings['name'];?>">
				<img src="/assets/img/arrowRight.png" class="arrowRight rightBtn slideBtn" alt="<?=$settings['name'];?>">
			</div>
		</div>
	</div>
</section>
<?=advertisement(2);?>
<section class="hotGameComt padder1">
	<div class="container">
      	<?php
		$gquery = "Played DESC";
    	$gtitle = "Trend";
      	?>
		<div class="flex ai jcb heading1Flex">
			<h2 class="heading1"><img src="/assets/img/fireImg.gif" width="37px" alt="<?=$settings['name'];?>"> <span class="cfirst">Hotestt Games</span> For You</h2>
			<a href="/subject/trend" class="viewmoreBtn">View more &nbsp; <i class="fa fa-angle-right"></i></a>
		</div>
		<div class="row">
          	<?php
            $page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
            $limit = 18;
            $startpoint = ($page * $limit) - $limit;
            if($page == 1) {
              $i = 1;
            } else {
              $i = $page * $limit;
            }
            $statement = "games WHERE status='enable'";
            $query = $db->query("SELECT * FROM {$statement} ORDER BY {$gquery} LIMIT {$startpoint} , {$limit}");
            if($query->num_rows > 0) {
              while($data = $query->fetch_assoc()) {
                $active_thumbnail = $data["ActiveThumbnail"];
                $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                $img_folder = $site_url."/uploads/images/";

                if($active_thumbnail == 1) {
                  $thumbnail = $img_folder.$data["image_store_url"];
                }else {
                  $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                }
            ?>
          	<div class="col-md-2 col-xs-6">
				<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
					<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
					<div class="gameBox2Inner">
						<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
					</div>
				</a>
			</div>
			<?php } $ver = "/"; } ?>	
		</div>
	</div>
</section>
<?=advertisement(2);?>
<section class="homeSec2 padder1">
	<div class="container">
		<div class="flex ai jcb heading1Flex">
			<h2 class="heading1"><img src="/assets/img/actions.png" alt="<?=$settings['name'];?>" width="23px"> &nbsp; <span class="cfirst">Action</span> Games</h2>
			<a href="/category/action" class="viewmoreBtn">View more &nbsp; <i class="fa fa-angle-right"></i></a>
		</div>
		<div class="row">
          	<?php
            $category = "action";
            $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
            if($category_check && $category_check->num_rows > 0) {
              $category_data = $category_check->fetch_assoc();
              $category_name = $category_data["name"];
              $page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
              $limit = 120;
              $startpoint = ($page * $limit) - $limit;
              if($page == 1) {
                $i = 1;
              } else {
                $i = $page * $limit;
              }
              $statement = "games";
              $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
              if($query->num_rows > 0) {
                while($data = $query->fetch_assoc()) {
                  $active_thumbnail = $data["ActiveThumbnail"];
                  $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                  $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                  $img_folder = $site_url."/uploads/images/";
                  if($active_thumbnail == 1) {
                    $thumbnail = $img_folder.$data["image_store_url"];
                  }else {
                    $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                  }
            ?>
			<div class="col-md-2 col-xs-6">
				<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
					<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
					<div class="gameBox2Inner">
						<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
					</div>
				</a>
			</div>
          <?php }  } } ?>	
		</div>
	</div>
</section>
<section class="homeSec3 padder1">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="row">
					<h2 class="heading1"><img src="/assets/img/actions.png" alt="<?=$settings['name'];?>" width="23px"> &nbsp; <span class="cfirst">Adventure</span> Games
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="/category/adventure" class="viewmoreBtn">More &nbsp; <i class="fa fa-angle-right"></i></a>
					</h2>
					<br>
					<div class="col-xs-6">
                      	<?php
                        $category = "action";
                        $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
                        if($category_check && $category_check->num_rows > 0) {
                          $category_data = $category_check->fetch_assoc();
                          $category_name = $category_data["name"];
                          $statement = "games";
                          $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT 9");
                          if($query->num_rows > 0) {
                            while($data = $query->fetch_assoc()) {
                              $active_thumbnail = $data["ActiveThumbnail"];
                              $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                              $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                              $img_folder = $site_url."/uploads/images/";

                              if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                              }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                              }
                        ?>
						<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
							<div class="gameBox2Inner">
								<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
							</div>
						</a>
                      	<?php }  } } ?>	
					</div>
					<div class="col-xs-6">
                      	<?php
                        $category = "action";
                        $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
                        if($category_check && $category_check->num_rows > 0) {
                          $category_data = $category_check->fetch_assoc();
                          $category_name = $category_data["name"];
                          $statement = "games";
                          $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT 9 OFFSET 10");
                          if($query->num_rows > 0) {
                            while($data = $query->fetch_assoc()) {
                              $active_thumbnail = $data["ActiveThumbnail"];
                              $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                              $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                              $img_folder = $site_url."/uploads/images/";

                              if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                              }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                              }
                        ?>
						<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
							<div class="gameBox2Inner">
								<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
							</div>
						</a>
                      	<?php }  } } ?>	
					</div>
				</div> <!-- row -->
			</div> <!-- col 4 -->
			<div class="col-md-4">
				<div class="row">
					<h2 class="heading1"><img src="/assets/img/shoot.png" alt="<?=$settings['name'];?>" width="23px"> &nbsp; <span class="csecond">Shooting</span> Games
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="/category/shooting" class="viewmoreBtn">More &nbsp; <i class="fa fa-angle-right"></i></a>
					</h2> <br>
					<div class="col-xs-6">
                      	<?php

                        $category = "shooting";
                        $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
                        if($category_check && $category_check->num_rows > 0) {
                          $category_data = $category_check->fetch_assoc();
                          $category_name = $category_data["name"];



                          $statement = "games";
                          $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT 9 OFFSET 20");

                          if($query->num_rows > 0) {
                            while($data = $query->fetch_assoc()) {
                              $active_thumbnail = $data["ActiveThumbnail"];
                              $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                              $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                              $img_folder = $site_url."/uploads/images/";

                              if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                              }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                              }

                        ?>
                      	
						<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
							<div class="gameBox2Inner">
								<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
							</div>
						</a>

						<?php }  } } ?>		
                      
					</div>

					<div class="col-xs-6">
						
						<?php

                        $category = "shooting";
                        $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
                        if($category_check && $category_check->num_rows > 0) {
                          $category_data = $category_check->fetch_assoc();
                          $category_name = $category_data["name"];



                          $statement = "games";
                          $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT 9 OFFSET 40");

                          if($query->num_rows > 0) {
                            while($data = $query->fetch_assoc()) {
                              $active_thumbnail = $data["ActiveThumbnail"];
                              $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                              $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                              $img_folder = $site_url."/uploads/images/";

                              if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                              }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                              }

                        ?>	
                      
						<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
							<div class="gameBox2Inner">
								<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
							</div>
						</a>

						<?php }  } } ?>		
                      
					</div>

				</div> <!-- row -->
			</div> <!-- col 4 -->


			<div class="col-md-4">
				<div class="row">
					
					<h2 class="heading1"><img src="/assets/img/puzz.png" alt="<?=$settings['name'];?>" width="23px"> &nbsp; <span class="cfirst">Puzzle</span> Games
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="/category/puzzle" class="viewmoreBtn">More &nbsp; <i class="fa fa-angle-right"></i></a>
					</h2> <br>
						
					<div class="col-xs-6">
                      	
                      	<?php

                        $category = "puzzle";
                        $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
                        if($category_check && $category_check->num_rows > 0) {
                          $category_data = $category_check->fetch_assoc();
                          $category_name = $category_data["name"];



                          $statement = "games";
                          $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT 9 OFFSET 80");

                          if($query->num_rows > 0) {
                            while($data = $query->fetch_assoc()) {
                              $active_thumbnail = $data["ActiveThumbnail"];
                              $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                              $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                              $img_folder = $site_url."/uploads/images/";

                              if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                              }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                              }

                        ?>	
                      
						<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
							<div class="gameBox2Inner">
								<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
							</div>
						</a>

						<?php }  } } ?>			
                      
                      
					</div>

					<div class="col-xs-6">
						
                      	<?php

                        $category = "puzzle";
                        $category_check = $db->query("SELECT * FROM game_categories WHERE slug='$category'");
                        if($category_check && $category_check->num_rows > 0) {
                          $category_data = $category_check->fetch_assoc();
                          $category_name = $category_data["name"];



                          $statement = "games";
                          $query = $db->query("SELECT * FROM {$statement} WHERE status='enable' and category LIKE '%$category_name%' ORDER BY id DESC LIMIT 9 OFFSET 100");

                          if($query->num_rows > 0) {
                            while($data = $query->fetch_assoc()) {
                              $active_thumbnail = $data["ActiveThumbnail"];
                              $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                              $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                              $img_folder = $site_url."/uploads/images/";

                              if($active_thumbnail == 1) {
                                $thumbnail = $img_folder.$data["image_store_url"];
                              }else {
                                $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                              }

                        ?>	
                      	
						<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="gameBox2 block td rel">
							<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>" class="gameBox2Img">
							<div class="gameBox2Inner">
								<p class="gameBox2Title abs cwhite"><?=$data["Title"];?></p>
							</div>
						</a>
                      
                      	<?php }  } } ?>		
                      	
					</div>

				</div> <!-- row -->
			</div> <!-- col 4 -->

		</div>

	</div>
</section>
<section class="catHome padder1">
	<div class="container">

		<div class="flex ai jcb heading3">
			<h2 class="heading1">Popular Games</h2>
			<a href="/subject/trend" class="viewmoreBtn">View more &nbsp; <i class="fa fa-angle-right"></i></a>
		</div> <br>	

		<div class="flex popHomeFlex jc">
			
          
          	<?php
			
			$gquery = "Played DESC";
    		$gtitle = "Trend";
			
			$statement = "games WHERE status='enable'";
            $query = $db->query("SELECT * FROM {$statement} ORDER BY {$gquery} LIMIT 20");

            if($query->num_rows > 0) {
              while($data = $query->fetch_assoc()) {
                $active_thumbnail = $data["ActiveThumbnail"];
                $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                $img_folder = $site_url."/uploads/images/";

                if($active_thumbnail == 1) {
                  $thumbnail = $img_folder.$data["image_store_url"];
                }else {
                  $thumbnail = (is_array(json_decode($data['Thumbnail']))) ? json_decode($data['Thumbnail'])[0] : $data["Thumbnail"];
                }
			?>
          		
			<div class="popCont">
				<a href="/play/<?=$data["Slug"];?>" alt="<?=$data["Title"];?>" class="homeCatBox td block">
					<img src="<?=$thumbnail;?>" loading="lazy" alt="<?=$data["Title"];?>">
					<p><?=$data["Title"];?></p>
				</a>
			</div>
			
          	<?php } } ?>
          	
		</div>

	</div>
</section>
<?php  include("footer.php"); ?>