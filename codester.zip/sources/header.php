<!DOCTYPE html>
<html lang="en">
<head>
	
	<meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  	<?php
	if (isset($_GET['a']) && $a == "play") {
      	
      $slug = addslashes(protect(htmlspecialchars($_GET["play"])));
      $game_check = $db->query("SELECT * FROM games WHERE Slug='$slug' and status='enable'");
      if($game_check && $game_check->num_rows > 0) {
        $game_data = $game_check->fetch_assoc();
        $title = $game_data['Title'];
        $description = $game_data['Description'];
        $keyword = $game_data['Tag'];
        $img = $game_data['Thumbnail'];
        
      } else {
        $title = $settings['title'];
        $description = $settings['description'];
        $keyword = $settings['keywords'];
      }
      
    } else {
      $title = $settings['title'];
      $description = $settings['description'];
      $keyword = $settings['keywords'];
    }


	?>
	<title><?php echo $title; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
  	<meta name="keywords" content="<?php echo $keyword; ?>">
  	<?php if (!empty($img)) { ?>
	<meta property="og:image" content="<?php echo $img ?>" />
	<?php } ?>
	<meta name="og:description" content="<?php echo $description; ?>">
	<meta name="og:keywords" content="<?php echo $keyword; ?>">
  	<meta name="publisher" content="<?php echo $title; ?>"/>
    <meta name="application-name" content="<?php echo $title; ?>">
    <link rel="canonical" href="<?=$settings['url']?>"/>
    <link rel="alternate" href="<?=$settings['url']?>"/>
    <?php if($settings['favicon']) { ?>
		<link rel="icon" type="image/png" href="<?= $settings['url'].$settings['favicon'] ?>">
	<?php } else { ?>
		<link rel="icon" type="image/png" href="/assets/img/favicon.png">
	<?php } ?>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  	<script src="/assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="/assets/css/slick.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
	<?php if ($_SESSION['mode'] && $_SESSION['mode'] == "light") { ?>
	<link rel="stylesheet" type="text/css" href="/assets/css/light.css">
	<?php } else { ?>
	<link rel="stylesheet" type="text/css" href="/assets/css/custom_styles.css">
	<?php } ?>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap" rel="stylesheet">
  	<script src="https://use.fontawesome.com/32efc5ddb7.js"></script>
    <?=advertisement(3);?>
</head>
<body>
<section class="header">
	<div class="container rel">
		<div class="bar abs">
			<span></span>
			<span></span>
			<span></span>
		</div>
		<div class="row">
			<div class="col-md-2">
				<a href="/">
				    <?php if($settings['white_logo']) { ?>
						<img src="<?= $settings['url'].$settings['white_logo'] ?>" class="logo-main">
					<?php } else { ?>
						<img src="/assets/img/logo-main.png" class="logo-main">
					<?php } ?>
				</a>
			</div>
			<div class="col-md-4">
             	<?php
					if(isset($_POST["search_done"]) && !empty($_POST["search"])) {
                      	$searching=0;
						$search = isset($_POST['search']) ? protect($_POST['search']) : "";
                     	header("Location: /search/$search");
                    }
				?>
				<form method="POST" action="">
					<div class="searchTopCont flex ai">
						<input type="text" name="search" class="searchTop" placeholder="Search Games">
						<button type="submit" name="search_done" class="searchBtnTop"></button>
					</div>
				</form>
			</div>
			<div class="col-md-6" align="right">
				<div class="flex ai headLinsFlex">
					<ul class="mainUl navSlide">
					    <li>
				<?php if ($_SESSION['mode'] && $_SESSION['mode'] == "light") { ?>
            	    <a href="/?mode=dark" class="main-link td"><i class="fa fa-moon-o" style="color:white;"></i></a>
            	<?php } else { ?>
            	    <a href="/?mode=light" class="main-link td"><i class="fa fa-sun-o" style="color:white;"></i></a>
            	<?php } ?>
            	</li>
						<li><a href="/" class="main-link td">
							<img src="/assets/img/homeImg.png" alt="<?=$settings['name'];?>">
							Home
						</a></li>
						<li><a href="/subject/trend" class="main-link td">
							<img src="/assets/img/gameIcom.png" alt="<?=$settings['name'];?>"> <?php //new ?>
							Trending Games
						</a></li>
                      	<li class="dropdownLi rel">
							<a href="#" class="main-link td catBtnHead dropdownClick">
							<img src="/assets/img/dice.png" alt="<?=$settings['name'];?>">
							Categories &nbsp;&nbsp;<i class="fa fa-angle-down rel"></i>
							</a>
							<ul class="dropdownUl">
							    <?php
							    $header = $db->query("SELECT * FROM game_categories ORDER BY id");
                                if($header && $header->num_rows > 0) {
                                  while($head = $header->fetch_assoc()) {
                                ?>
                				<li><a href="/category/<?=$head['slug']?>">
									<img src="/assets/img/<?=$head['slug']?>.png" alt="<?=$head['name']?> Games by <?=$settings['name'];?>">
									<?=$head['name']?>
								</a></li>
                				<?php } } ?>
							</ul>
						</li>
					</ul>
					<div class="socialHeadFlex flex ai ml10 navSlide tac">
						<a target="_blank" href="<?=$social['facebook_profile']?>"><i class="fa fa-facebook"></i></a>
						<a target="_blank" href="<?=$social['twitter_profile']?>"><i class="fa fa-twitter"></i></a>
						<a target="_blank" href="<?=$social['instagram']?>"><i class="fa fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>