<?php
$prefix = protect($_GET['prefix']);
$query = $db->query("SELECT * FROM pages WHERE prefix='$prefix'");
if($query->num_rows==0) {
    $redirect = $settings['url'];
    header("Location: $redirect");
}
$row = $query->fetch_assoc();
?>

<?php include("header.php"); ?>

<section class="homeSec2 padder1">
	<div class="container">

		<div class="flex ai jcb heading1Flex">
			<h2 class="heading1"><img src="/assets/img/favicon.png" width="23px"> &nbsp; <span class="cfirst">#<?php echo $row['title']; ?></span></h2>
		</div>


		<?php echo $row['content']; ?>


	</div>
</section>




    


<?php include("footer.php"); ?>

   