<?php 
if(isset($_POST["gameFrame"]) && $_POST["gameFrame"] == "true") {
	if(isset($_POST["play"])){
      $play = $_POST["play"];
    } else {
        $play = "1111";
    }
    if(isset($_POST["gftm"])){
      $timer = $_POST["gftm"];
    } else {
        $timer = "1111";
    }
	
	if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') { 
		$slug = addslashes(protect(htmlspecialchars($_GET["play"])));
		$game_check = $db->query("SELECT * FROM games WHERE Slug='$slug'");
		if($game_check && $game_check->num_rows > 0) {
			if($play == "1") {
				$db->query("UPDATE games SET Played=Played+1 WHERE Slug='$slug'");
				exit("ok");
			} elseif($timer == "1") {
				$db->query("UPDATE games SET Playtime=Playtime+1 WHERE Slug='$slug'");
				exit("ok");
			}
		} else {
			exit("error");
		}
	} else{ 
		exit("not ajax");
	} 
}
include("header.php"); 
if(isset($_GET["play"]) && !empty($_GET["play"])) {
  $slug = addslashes(protect(htmlspecialchars($_GET["play"])));
  $game_check = $db->query("SELECT * FROM games WHERE Slug='$slug' and status='enable'");
  if($game_check && $game_check->num_rows > 0) {
    $game_data = $game_check->fetch_assoc();
    $max_recommended_games = 7;
    $recomended_games = $db->query("SELECT * FROM games WHERE status='enable' ORDER BY RAND() LIMIT $max_recommended_games");
    
    $recomended_games_b = $db->query("SELECT * FROM games WHERE status='enable' ORDER BY RAND() LIMIT 6 OFFSET 18");
    $recomended_games_c = $db->query("SELECT * FROM games WHERE status='enable' ORDER BY RAND() LIMIT 6 OFFSET 50");
?>

<section class="playPage">
	<div class="catHome">
		<div class="container">
			<div class=" popSlider ">
              <?php
                if($recomended_games && $recomended_games->num_rows > 0) {
                  while($list = $recomended_games->fetch_assoc()) {
                      $active_thumbnail = $list["ActiveThumbnail"];
                      $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                      $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                      $img_folder = $site_url."/uploads/images/";

                      if($active_thumbnail == 1) {
                          $thumbnail = $img_folder.$list["image_store_url"];
                      }else {
                          $thumbnail = (is_array(json_decode($list['Thumbnail']))) ? json_decode($list['Thumbnail'])[0] : $list["Thumbnail"];
                      }
                 ?>
				<div class="popCont">
					<a href="/play/<?=$list["Slug"];?>" title="<?=$list["Title"];?>" class="homeCatBox td block">
						<img src="<?=$thumbnail;?>" title="<?=$list["Title"];?>">
						<p><?=$list["Title"];?></p>
					</a>
				</div>
				<?php } } ?>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-9 iframeArea">
              	<script>
                  var clickIframe = window.setInterval(checkFocus, 1000);
                  var i = 0;
                  function checkFocus() {
                    if(document.activeElement == document.getElementById("gameFrame")) {
                      if(i == "5") {
                        $.ajax({
                          type: "POST",
                          url: window.location.href,
                          data: "gameFrame=true&play=1",
                          success: function() {}
                        });
                      }else if(i > 10) {
                        $.ajax({
                          type: "POST",
                          url: window.location.href,
                          data: "gameFrame=true&gftm=1",
                          success: function() {}
                        });
                      }
                      i++;
                    }
                  }
                </script>
				<iframe id="gameFrame" class="game-frame" src="<?=$settings['url'];?>embed/<?=$slug;?>" scrolling="none" frameborder="0" title="<?=$game_data["Title"];?>" allowfullscreen></iframe>
              	<?php
                if($recomended_games_b && $recomended_games_b->num_rows > 0) {
                  while($list = $recomended_games_b->fetch_assoc()) {
                      $active_thumbnail = $list["ActiveThumbnail"];
                      $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                      $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                      $img_folder = $site_url."/uploads/images/";

                      if($active_thumbnail == 1) {
                          $thumbnail = $img_folder.$list["image_store_url"];
                      }else {
                          $thumbnail = (is_array(json_decode($list['Thumbnail']))) ? json_decode($list['Thumbnail'])[0] : $list["Thumbnail"];
                      }
                 ?>
				<a href="/play/<?=$list["Slug"];?>" class="gameBox2 block td rel" title="<?=$list["Title"];?>">
					<img src="<?=$thumbnail;?>" class="gameBox2Img" title="<?=$list["Title"];?>">
					<div class="gameBox2Inner">
						<p class="gameBox2Title abs cwhite"><?=$list["Title"];?></p>
					</div>
				</a>
				<?php } } ?>
             	<div class="flex ai jcb playShare rr">
                    <div class="cont">
                    <?php if($settings['white_logo']) { ?>
						<img src="<?= $settings['url'].$settings['white_logo'] ?>" width="130px">
					<?php } else { ?>
						<img src="/assets/img/logo-main.png" width="130px">
					<?php } ?>
                    </div>
                    <div class="cont">
                      <a href="JavaScript:" data-toggle="modal" data-target="#embadModal"><i class="fa fa-code"></i> &nbsp; Embed</a>
                      &nbsp;&nbsp;
                      <a target="_blank" href="https://www.facebook.com/sharer.php?u=<?=$settings['url']?>play/<?=$slug;?>"><i class="fa fa-facebook"></i></a>
                      <a target="_blank" href="https://api.whatsapp.com/send?text=Play any games you want exclusive on Eil Games : <?php echo $settings['url']; ?>play/<?=$slug;?>"><i class="fa fa-whatsapp"></i></a>
                      <a target="_blank" href="https://twitter.com/intent/tweet?text=Play any games you want exclusive on Eil Games &url=<?=$settings['url']?>play/<?=$slug;?>"><i class="fa fa-twitter"></i></a>
                    	
                      &nbsp;&nbsp;&nbsp;
                      <span onclick="openFullscreen();" class="us pointer fw3 fs18"><i class="fa fa-arrows-alt" aria-hidden="true"></i> &nbsp; fullscreen</span>
                    </div>
                </div> <!-- playShare -->
				<!-- Modal -->
				<div id="embadModal" class="modal fade" role="dialog">
				  <div class="modal-dialog">
				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title">Embed It Now...</h4>
				      </div>
				      <div class="modal-body fs16 cgray">
				      	<p>Embed this game on your web page or website.</p>
				      	<br>
				      	<textarea class="urlTxt w100 embedTxt" readonly><iframe src="<?=$settings['url'];?>embed/<?=$slug;?>" frameborder="0" width="600px" height="400px"></iframe></textarea>
				      	<p class="w100 inline btn1 pointer us fw3 trans br8 flex ai jc copyEmbedBtn"><i class="fa fa-clipboard"></i> &nbsp; <span class="copyTxt">Copy Embed Code</span></p>
				      </div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				      </div>
				    </div>
				  </div>
				</div>
				<div class="underiframe">
                <?php
                if($recomended_games_c && $recomended_games_c->num_rows > 0) {
                  while($list = $recomended_games_c->fetch_assoc()) {
                      $active_thumbnail = $list["ActiveThumbnail"];
                      $actual_link = parse_url((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]");
                      $site_url = $actual_link["scheme"]."://".$actual_link["host"].($actual_link["path"] ?? "");
                      $img_folder = $site_url."/uploads/images/";

                      if($active_thumbnail == 1) {
                          $thumbnail = $img_folder.$list["image_store_url"];
                      }else {
                          $thumbnail = (is_array(json_decode($list['Thumbnail']))) ? json_decode($list['Thumbnail'])[0] : $list["Thumbnail"];
                      }
                 ?>
				<a href="/play/<?=$list["Slug"];?>" class="gameBox2 block td rel" title="<?=$list["Title"];?>">
					<img src="<?=$thumbnail;?>" class="gameBox2Img" title="<?=$list["Title"];?>">
					<div class="gameBox2Inner">
						<p class="gameBox2Title abs cwhite"><?=$list["Title"];?></p>
					</div>
				</a>
				<?php } } ?>
				</div> <!-- underFrame -->
				<div class="col-md-12">
					<div class="block1 playContent mb20">
						<h2 class="fs26 ">Description</h2>
						<br>
						<p class="cgray">
							<?=$game_data['Description'];?>
						</p>
                        <br><br>
						<h3 class="smallHead">Instruction</h3>
						<p class="cgray mt20">
							<?=$game_data['Instructions'];?>
						</p>
                        <br><br>
						<h3 class="smallHead">Specifications</h3>
						<ul class="mt20 cgray">
							<li>Easy to play</li>
						</ul>
					</div>
				</div>
				<div class="col-md-12">
					<div class="flex ai jcb">
                      	<?=advertisement(2);?>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<div class="w100">
							<p class="mb15">So <span class="csecond">many more games</span> you can play!</p>
							<a href="/subject/all" class="btn2 fw3 br8 trans inline w100">More games &nbsp; <i class="fa fa-angle-down"></i></a>
						</div>
					</div>
				</div> <!-- col -->
			</div> <!-- col -->
			<div class="col-md-3">
				<div class="playShare br8">
					<h2 class="heading1 m0">Embed It & Share It</h2>
					<p class="mt10 cgray">
						Embed Games at your portal now and share games on social media now.
					</p>
					<br>
					<div class="flex palyShareFlex">
						<a target="_blank" href="https://www.facebook.com/sharer.php?u=<?=$settings['url']?>play/<?=$slug;?>" class="playShareBtn fb">
							<i class="fa fa-facebook"></i>
						</a>
						&nbsp;&nbsp;&nbsp;
						<a target="_blank" href="https://twitter.com/intent/tweet?text=Play any games you want exclusive on Eil Games &url=<?=$settings['url']?>play/<?=$slug;?>" class="playShareBtn tw">
							<i class="fa fa-twitter"></i>
						</a>
						&nbsp;&nbsp;&nbsp;
						<a target="_blank" href="https://api.whatsapp.com/send?text=Play any games you want exclusive on Eil Games : <?php echo $settings['url']; ?>play/<?=$slug;?>" class="playShareBtn whats">
							<i class="fa fa-whatsapp"></i>
						</a>
					</div>
					<hr class="hr1">
					<input type="text" name="refLink" class="w100 urlTxt br8" value="<?=$settings['url'];?>embed/<?=$slug;?>">
				</div>
				<br>
              	<?=advertisement(1);?>
              	<br>
              	<?=advertisement(1);?>
			</div>
		</div>
	</div>
</section>
<?php } else { header("Location: /"); } } include("footer.php"); ?>