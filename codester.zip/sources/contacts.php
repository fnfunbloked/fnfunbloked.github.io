<?php include("header.php"); ?>

    
<section class="homeSec2 padder1">
	<div class="container">

		<div class="flex ai jcb heading1Flex">
			<h2 class="heading1"><img src="/assets/img/favicon.png" width="23px"> &nbsp; <span class="cfirst">#Contact Us</span></h2>
		</div>
      
    <div class="contact-form-section">
        <div class="container">
            <div class="row">
                <div class="offset-lg-3 col-lg-6 offset-md-1 col-md-9">
                    <div class="contact-form-wrap">
                        <?php
                        $FormBTN = protect($_POST['pw_send']);
                        if($FormBTN == "message") {
                            $name = protect($_POST['name']);
                            $email = protect($_POST['email']);
                            $subject = protect($_POST['subject']);
                            $message = protect($_POST['message']);
                            if(empty($name) or empty($email) or empty($subject) or empty($message)) {
                                echo error($lang['error_20']);
                            } elseif(!isValidEmail($email)) {
                                echo error($lang['error_34']);
                            } else {
                                $mail = new PHPMailer;
                                $mail->isSMTP();
                                $mail->SMTPDebug = 0;
                                $mail->Host = $smtpconf["host"];
                                $mail->Port = $smtpconf["port"];
                                $mail->SMTPAuth = $smtpconf['SMTPAuth'];
                                $mail->Username = $smtpconf["user"];
                                $mail->Password = $smtpconf["pass"];
                                if ($smtpconf["ssl"] == "1") {
                                    $mail->SMTPSecure = "ssl";
                                }
                                $mail->setFrom($email, $name);
                                $mail->addAddress($settings['supportemail'], $settings['supportemail']);
                                //Set the subject line
                                $lang = array();
                                $mail->Subject = $subject;
                                $mail->msgHTML($message);
                                //Replace the plain text body with one created manually
                                $mail->AltBody = $message;
                                //Attach an image file
                                //send the message, check for errors
                                $send = $mail->send();
                                if($send) { 
                                    echo success("Your query has been received we will be back in 1-2 business days.");
                                } else {
                                    echo error($lang['error_35']);
                                }
                            }
                        }
                        ?>
                        <form class="contact-form" action="" method="POST">
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="name" placeholder="<?php echo $lang['placeholder_7']; ?>">
                            </div>
                            <div class="form-group">
                              <input type="email" class="form-control" id="" name="email" placeholder="<?php echo $lang['placeholder_8']; ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="subject" placeholder="<?php echo $lang['placeholder_9']; ?>">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" rows="5" name="message" id="comment" placeholder="<?php echo $lang['placeholder_10']; ?>"></textarea>
                            </div>
                            <button type="submit" name="pw_send" value="message" class="btn btn-default"><?php echo $lang['btn_26']; ?></button>
                        </form>
                    </div>
                </div>
            </div>
    	</div>  
    </div>

	</div>
</section>

<?php include("footer.php"); ?>