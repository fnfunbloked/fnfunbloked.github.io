<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Manage Content</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
					
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="content mt-3">
   <div class="col-md-12">
		<div class="card">
            <div class="card-body">
        		<?php
        		if(isset($_POST['btn_save'])) {
        			
        			$footer_section_h1 = protect($_POST['footer_section_h1']);
        			$footer_section_text = protect($_POST['footer_section_text']);
        			
        			$footer_section_part_1_h1 = protect($_POST['footer_section_part_1_h1']);
        			$footer_section_part_1_text = protect($_POST['footer_section_part_1_text']);
        			
        			$footer_section_part_2_h1 = protect($_POST['footer_section_part_2_h1']);
        			$footer_section_part_2_text = protect($_POST['footer_section_part_2_text']);
        			
        			$footer_section_part_3_h1 = protect($_POST['footer_section_part_3_h1']);
        			$footer_section_part_3_text = protect($_POST['footer_section_part_3_text']);
        			
        			$footer = $_POST['footer'];
        			$header = $_POST['header'];
        			
        			if(empty($footer_section_h1) or empty($footer_section_text) or empty($footer_section_part_1_h1) or empty($footer_section_part_1_text) or empty($footer_section_part_2_h1) or empty($footer_section_part_2_text) or empty($footer_section_part_3_h1) or empty($footer_section_part_3_text)) {
        				echo error("All fields are required."); 
        			} else {
        				$update = $db->query("UPDATE settings SET footer_section_h1='$footer_section_h1',footer_section_text='$footer_section_text'");
        				$update = $db->query("UPDATE settings SET footer_section_part_1_h1='$footer_section_part_1_h1',footer_section_part_1_text='$footer_section_part_1_text'");
        				$update = $db->query("UPDATE settings SET footer_section_part_2_h1='$footer_section_part_2_h1',footer_section_part_2_text='$footer_section_part_2_text'");
        				$update = $db->query("UPDATE settings SET footer_section_part_3_h1='$footer_section_part_3_h1',footer_section_part_3_text='$footer_section_part_3_text'");
        				$update = $db->query("UPDATE settings SET footer='$footer',header='$header'");
        				$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
        				$settings = $settingsQuery->fetch_assoc();
        				echo success("Your changes was saved successfully.");
        			}
        		}
        		?>
        		<form action="" method="POST">
        			<div class="form-group">
        				<label>Footer Section #1 Heading</label>
        				<textarea class="form-control" name="footer_section_h1"><?php echo $settings['footer_section_h1']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #1 Content</label>
        				<textarea class="form-control" name="footer_section_text"><?php echo $settings['footer_section_text']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #2 Heading</label>
        				<textarea class="form-control" name="footer_section_part_1_h1"><?php echo $settings['footer_section_part_1_h1']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #2 Content</label>
        				<textarea class="form-control" name="footer_section_part_1_text"><?php echo $settings['footer_section_part_1_text']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #3 Heading</label>
        				<textarea class="form-control" name="footer_section_part_2_h1"><?php echo $settings['footer_section_part_2_h1']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #3 Content</label>
        				<textarea class="form-control" name="footer_section_part_2_text"><?php echo $settings['footer_section_part_2_text']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #4 Heading</label>
        				<textarea class="form-control" name="footer_section_part_3_h1"><?php echo $settings['footer_section_part_3_h1']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Footer Section #4 Content</label>
        				<textarea class="form-control" name="footer_section_part_3_text"><?php echo $settings['footer_section_part_3_text']; ?></textarea>
        			</div>
        			
        			<div class="form-group">
        				<label>Add code in footer</label>
        				<textarea class="form-control" name="footer"><?php echo $settings['footer']; ?></textarea>
        			</div>
        			<div class="form-group">
        				<label>Add code in header</label>
        				<textarea class="form-control" name="header"><?php echo $settings['header']; ?></textarea>
        			</div>
        			<button type="submit" class="btn btn-primary" name="btn_save"><i class="fa fa-check"></i> Save changes</button>
        		</form>
            </div>
        </div>
    </div>
</div>